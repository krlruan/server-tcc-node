// ---------------------------------------------------------------------------
// phish-score.js
// Adaptação do algoritmo "Phish-Score" (Khalique Khan, 2023 — PhishScan).
// Módulo puro (sem APIs do Chrome): roda no service worker e também no Node,
// o que permite reutilizar o mesmo código nos experimentos do TCC.
//
// Cada característica que dispara soma o seu peso; os pesos somam 100.
// Etapas:
//   1) avaliarLocal(url)  -> características que dependem só da URL (offline)
//   2) aplicarRede(local, resposta do servidor) -> SSL, DNS, idade, redirecionamento
// ---------------------------------------------------------------------------

export const PESOS = {
  // Léxicas
  idn: 5,
  caracteres: 5,
  estrutura: 5,
  tamanho: 5,
  arroba: 5,
  redirecionamento: 3,
  encurtador: 2,
  protocoloNoDominio: 2,
  tamanhoDominio: 3,
  pontos: 2,
  palavraMedia: 2,
  palavraMaior: 3,
  // Baseadas no host
  idadeDominio: 3,
  dns: 5,
  similaridade: 15,
  subdominio: 10,
  extensao: 10,
  ssl: 10,
  ip: 5,
};

export const LIMIAR_PHISHING = 40; // definido no artigo
export const LIMIAR_SUSPEITO = 20; // PREMISSA: o artigo não informa o corte de "Maybe Phishy"

// ---------------------------------------------------------------------------
// Listas (editáveis — parte do que será calibrado nos testes)
// ---------------------------------------------------------------------------

const ENCURTADORES = new Set([
  "bit.ly", "tinyurl.com", "goo.gl", "t.co", "is.gd", "buff.ly", "adf.ly", "bl.ink",
  "lnkd.in", "rebrand.ly", "migre.me", "ow.ly", "cutt.ly", "shorturl.at", "short.io",
  "tiny.cc", "s.id", "rb.gy", "t.ly",
]);

const TLDS_ABUSADOS = new Set([
  "top", "xyz", "icu", "tk", "ml", "ga", "cf", "gq", "buzz", "click", "link", "cyou",
  "cfd", "sbs", "rest", "monster", "quest", "bond", "cam", "work", "support", "zip",
  "mov", "vip", "world",
]);

// Hospedagem gratuita / DNS dinâmico muito usados em phishing
const SUFIXOS_ABUSADOS = [
  "duckdns.org", "ddns.net", "no-ip.org", "2waky.com", "r2.dev", "trycloudflare.com",
];

const SLDS_COMPOSTOS = new Set(["com", "net", "org", "gov", "edu", "co", "ac", "mil"]);

const CARACTERES_SUSPEITOS = new Set(Array.from("@!$*()[]{}|\\^~`'\"<>;"));

// [nome da marca, domínios oficiais]
const MARCAS = [
  ["paypal", ["paypal.com", "paypal.com.br", "paypal.me"]],
  ["amazon", ["amazon.com", "amazon.com.br", "amazon.co.uk", "amazon.de"]],
  ["google", ["google.com", "google.com.br", "gmail.com", "goo.gl", "gstatic.com", "googleapis.com"]],
  ["youtube", ["youtube.com", "youtu.be"]],
  ["microsoft", ["microsoft.com", "microsoftonline.com", "live.com", "office.com", "outlook.com"]],
  ["apple", ["apple.com", "icloud.com"]],
  ["facebook", ["facebook.com", "fb.com"]],
  ["instagram", ["instagram.com"]],
  ["whatsapp", ["whatsapp.com", "whatsapp.net"]],
  ["netflix", ["netflix.com"]],
  ["linkedin", ["linkedin.com"]],
  ["twitter", ["twitter.com", "x.com"]],
  ["telegram", ["telegram.org", "t.me"]],
  ["discord", ["discord.com", "discord.gg"]],
  ["tiktok", ["tiktok.com"]],
  ["spotify", ["spotify.com"]],
  ["dropbox", ["dropbox.com"]],
  ["github", ["github.com"]],
  ["ebay", ["ebay.com"]],
  ["binance", ["binance.com"]],
  ["coinbase", ["coinbase.com"]],
  ["aliexpress", ["aliexpress.com"]],
  ["shopee", ["shopee.com.br", "shopee.com"]],
  ["mercadolivre", ["mercadolivre.com.br", "mercadolibre.com"]],
  ["mercadopago", ["mercadopago.com.br", "mercadopago.com"]],
  ["magazineluiza", ["magazineluiza.com.br", "magalu.com.br"]],
  ["americanas", ["americanas.com.br"]],
  ["casasbahia", ["casasbahia.com.br"]],
  ["itau", ["itau.com.br", "itau.com"]],
  ["bradesco", ["bradesco.com.br"]],
  ["santander", ["santander.com.br", "santander.com"]],
  ["caixa", ["caixa.gov.br"]],
  ["nubank", ["nubank.com.br"]],
  ["sicredi", ["sicredi.com.br"]],
  ["sicoob", ["sicoob.com.br"]],
  ["bancointer", ["bancointer.com.br"]],
  ["pagseguro", ["pagseguro.uol.com.br", "pagseguro.com.br"]],
  ["picpay", ["picpay.com"]],
  ["serasa", ["serasa.com.br", "serasaexperian.com.br"]],
  ["correios", ["correios.com.br"]],
];

// ---------------------------------------------------------------------------
// Utilidades de host
// ---------------------------------------------------------------------------

const ehIp = (host) => /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.startsWith("[");

const ehHostLocal = (host) =>
  host === "localhost" ||
  host.endsWith(".localhost") ||
  /^(127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/.test(host);

export function dominioRegistravel(host) {
  const p = host.split(".");
  if (p.length <= 2) return host;
  const tld = p[p.length - 1];
  const sld = p[p.length - 2];
  return tld.length === 2 && SLDS_COMPOSTOS.has(sld) ? p.slice(-3).join(".") : p.slice(-2).join(".");
}

function partesDoHost(host) {
  const registravel = dominioRegistravel(host);
  const [sld, ...resto] = registravel.split(".");
  const subdominios =
    host.length > registravel.length ? host.slice(0, host.length - registravel.length - 1).split(".") : [];
  return { registravel, sld, tld: resto[resto.length - 1] ?? "", subdominios };
}

const noDominio = (host, d) => host === d || host.endsWith("." + d);

export const ehSiteOficial = (host) => MARCAS.some(([, doms]) => doms.some((d) => noDominio(host, d)));

// ---------------------------------------------------------------------------
// Características léxicas
// ---------------------------------------------------------------------------

function temIdn(urlStr, host) {
  const autoridade = urlStr.split("/")[2] ?? "";
  return host.split(".").some((l) => l.startsWith("xn--")) || /[^\x00-\x7f]/.test(autoridade);
}

function contarCaracteresSuspeitos(u) {
  let total = 0;
  for (const c of u.href.split("#")[0]) if (CARACTERES_SUSPEITOS.has(c)) total++;
  return total;
}

function estruturaSuspeita(u) {
  const semHash = u.href.split("#")[0];
  if ((semHash.match(/\?/g) || []).length > 1) return true;
  if (!u.search) return false;
  return u.search
    .slice(1)
    .split("&")
    .some((par) => par === "" || !par.includes("=") || par.startsWith("="));
}

function palavrasDaUrl(u) {
  return `${u.hostname}${u.pathname}`.split(/[^a-z0-9]+/i).filter(Boolean);
}

// ---------------------------------------------------------------------------
// Características baseadas no host
// ---------------------------------------------------------------------------

function distancia(a, b) {
  if (Math.abs(a.length - b.length) > 1) return 2; // só importa saber se é exatamente 1
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      d[i][j] = Math.min(
        d[i - 1][j] + 1,
        d[i][j - 1] + 1,
        d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
    }
  }
  return d[a.length][b.length];
}

// Versões "de-leetadas" do rótulo: paypa1 -> paypal, g00gle -> google, rn -> m ...
function variantes(rotulo) {
  const troca = { 0: "o", 3: "e", 4: "a", 5: "s", 7: "t" };
  const base = rotulo.replace(/[03457]/g, (c) => troca[c]);
  return [
    ...new Set([
      rotulo,
      base.replace(/1/g, "l"),
      base.replace(/1/g, "i"),
      rotulo.replace(/rn/g, "m").replace(/vv/g, "w"),
    ]),
  ];
}

function rotuloImitaMarca(rotulo, marca, ehSubdominio) {
  for (const v of variantes(rotulo)) {
    if (v === marca && (ehSubdominio || v !== rotulo)) return true; // paypal.evil.com | paypa1.com
    const tokens = v.split("-").filter(Boolean);
    if (tokens.length > 1 && tokens.includes(marca)) return true; // paypal-login.com
    if (marca.length >= 6 && tokens.some((t) => distancia(t, marca) === 1)) return true; // paypall.com
  }
  return false;
}

function similaridadeDeDominio(host, p) {
  const rotulos = host.split(".");
  const tldFinal = rotulos[rotulos.length - 1];
  for (const [nome, oficiais] of MARCAS) {
    if (oficiais.some((d) => noDominio(host, d))) continue; // é o site oficial
    if (rotuloImitaMarca(p.sld, nome, false)) return true;
    if (p.sld === nome && TLDS_ABUSADOS.has(tldFinal)) return true; // amazon.xyz
    if (p.subdominios.some((s) => rotuloImitaMarca(s, nome, true))) return true;
    // marca "quebrada" por pontos: pay.pal.xyz
    if (nome.length >= 5 && rotulos.join("").includes(nome) && !rotulos.some((r) => r.includes(nome))) {
      return true;
    }
  }
  return false;
}

function subdominiosAnomalos(host, p) {
  const uteis = p.subdominios.filter((s) => s !== "www");
  if (uteis.length >= 3) return true;
  // marca conhecida usada como subdomínio de um domínio que não é dela
  return MARCAS.some(
    ([nome, oficiais]) =>
      !oficiais.some((d) => noDominio(host, d)) && uteis.some((s) => variantes(s).includes(nome))
  );
}

function extensaoAbusada(host) {
  return (
    TLDS_ABUSADOS.has(host.split(".").pop()) || SUFIXOS_ABUSADOS.some((s) => noDominio(host, s))
  );
}

// ---------------------------------------------------------------------------
// API pública
// ---------------------------------------------------------------------------

const somar = (flags) => flags.reduce((total, f) => total + (PESOS[f] ?? 0), 0);

/** Características que dependem apenas da URL. Retorna null se não for http(s). */
export function avaliarLocal(urlStr) {
  let u;
  try {
    u = new URL(urlStr);
  } catch {
    return null;
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") return null;

  const host = u.hostname.toLowerCase().replace(/\.$/, "");
  if (ehHostLocal(host)) {
    return { score: 0, flags: [], host, registravel: host, ehIp: false, local: true };
  }

  const ip = ehIp(host);
  const p = ip ? null : partesDoHost(host);
  const palavras = palavrasDaUrl(u);
  const media = palavras.length ? palavras.reduce((s, w) => s + w.length, 0) / palavras.length : 0;

  const sinais = {
    idn: temIdn(urlStr, host),
    caracteres: contarCaracteresSuspeitos(u) > 4,
    estrutura: estruturaSuspeita(u),
    tamanho: u.href.split("#")[0].length > 70,
    // Só a parte de credenciais (usuario@site): '/@perfil' em caminhos é comum em sites legítimos
    arroba: Boolean(u.username || u.password),
    encurtador: ENCURTADORES.has(host.replace(/^www\./, "")),
    protocoloNoDominio: host.includes("http"),
    tamanhoDominio: !ip && p.sld.length >= 14,
    pontos: !ip && host.split(".").length - 1 > 3,
    palavraMedia: media > 6,
    palavraMaior: palavras.some((w) => w.length > 20), // PREMISSA: limiar não informado no artigo
    similaridade: !ip && similaridadeDeDominio(host, p),
    subdominio: !ip && subdominiosAnomalos(host, p),
    extensao: !ip && extensaoAbusada(host),
    ssl: u.protocol === "http:",
    ip,
  };

  const flags = Object.keys(sinais).filter((k) => sinais[k]);
  return { score: somar(flags), flags, host, registravel: p ? p.registravel : host, ehIp: ip, local: false };
}

/** Soma as características que só o servidor consegue verificar. */
export function aplicarRede(local, rede) {
  const flags = new Set(local.flags);
  if (rede) {
    if (rede.ssl === false) flags.add("ssl");
    if (rede.dns === false) flags.add("dns");
    if (typeof rede.idade_dias === "number" && rede.idade_dias < 365) flags.add("idadeDominio");
    if (rede.redirecionamento === true) flags.add("redirecionamento");
  }
  const lista = [...flags];
  return { ...local, flags: lista, score: somar(lista), rede: Boolean(rede) };
}

/** 'safe' | 'suspicious' | 'dangerous' (equivalem a Genuine / Maybe Phishy / Phishy) */
export function classificar(score) {
  if (score >= LIMIAR_PHISHING) return "dangerous";
  if (score >= LIMIAR_SUSPEITO) return "suspicious";
  return "safe";
}
