// ---------------------------------------------------------------------------
// Site Guard — service worker (Manifest V3)
//
// A cada navegação da aba principal:
//   1) calcula o phish-score local (offline) e, se já for perigoso, injeta o aviso na hora;
//   2) consulta o servidor (SSL, DNS, idade do domínio, redirecionamento), recalcula
//      e injeta o aviso se o resultado final for perigoso;
//   3) registra a visita (contagem por hora + link + score + características).
//
// Estrutura em chrome.storage.local:
//   enabled   : boolean
//   totals    : { safe, suspicious, dangerous }
//   reported  : { "host.com": timestamp }
//   hourly    : { "2026-09-29T14": { safe, suspicious, dangerous, sites: {
//                   "https://exemplo.com/pagina": { url, host, status, score, flags, visits, lastVisit }
//               } } }
// Em chrome.storage.session (some ao fechar o navegador):
//   liberados : { "host.com": timestamp }   (usuário clicou em "prosseguir")
//   cache:*   : respostas do servidor
// ---------------------------------------------------------------------------

import { avaliarLocal, aplicarRede, classificar, ehSiteOficial } from "./phish-score.js";
import { consultarServidor } from "./servidor.js";

const RETENTION_DAYS = 30;
const EMPTY_TOTALS = { safe: 0, suspicious: 0, dangerous: 0 };

// Lista fixa de exemplo + sites reportados pelo usuário. Têm prioridade sobre o score.
const DANGEROUS_HOSTS = ["testsafebrowsing.appspot.com", "malware.testing.google.test"];

// Fila: garante que leituras/gravações no storage não se sobreponham
let queue = Promise.resolve();
const enqueue = (task) => {
  const run = queue.then(task);
  queue = run.catch((err) => console.error("[Site Guard]", err));
  return run;
};

const isListed = (host, list) =>
  (Array.isArray(list) ? list : Object.keys(list)).some(
    (entry) => host === entry || host.endsWith("." + entry)
  );

const semWww = (host) => host.replace(/^www\./, "");

// ---------------------------------------------------------------------------
// Registro por hora
// ---------------------------------------------------------------------------

const pad = (n) => String(n).padStart(2, "0");

function hourKey(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}`;
}

function pruneOldHours(hourly) {
  const cutoff = hourKey(Date.now() - RETENTION_DAYS * 24 * 3600 * 1000);
  for (const key of Object.keys(hourly)) {
    if (key < cutoff) delete hourly[key];
  }
}

async function registrarVisita(rawUrl, status, resultado) {
  const url = new URL(rawUrl);
  const { totals = { ...EMPTY_TOTALS }, hourly = {} } = await chrome.storage.local.get([
    "totals",
    "hourly",
  ]);
  const now = Date.now();

  const bucket = (hourly[hourKey(now)] ??= { ...EMPTY_TOTALS, sites: {} });
  bucket[status] += 1;
  totals[status] = (totals[status] ?? 0) + 1;

  // Guarda o link sem query string nem hash (podem conter tokens/dados pessoais)
  const link = (url.origin + url.pathname).slice(0, 2048);
  const site = (bucket.sites[link] ??= { url: link, host: url.hostname, visits: 0 });
  site.status = status;
  site.score = resultado.score;
  site.flags = resultado.flags;
  site.visits += 1;
  site.lastVisit = now;

  pruneOldHours(hourly);
  await chrome.storage.local.set({ totals, hourly });
}

async function reportSite(host) {
  const clean = semWww(String(host).toLowerCase());
  if (!clean) return;
  const { reported = {} } = await chrome.storage.local.get("reported");
  reported[clean] = Date.now();
  await chrome.storage.local.set({ reported });
}

// ---------------------------------------------------------------------------
// "Prosseguir" (liberação por sessão)
// ---------------------------------------------------------------------------

async function hostLiberado(host) {
  const { liberados = {} } = await chrome.storage.session.get("liberados");
  return Boolean(liberados[host]);
}

async function liberarHost(host) {
  const { liberados = {} } = await chrome.storage.session.get("liberados");
  liberados[host] = Date.now();
  await chrome.storage.session.set({ liberados });
}

// ---------------------------------------------------------------------------
// Injeção do aviso
// ---------------------------------------------------------------------------

async function injetarAviso(detalhes) {
  // documentIds garante que só o documento analisado recebe o aviso,
  // mesmo que a aba já tenha navegado para outra página.
  const alvo = detalhes.documentId
    ? { tabId: detalhes.tabId, documentIds: [detalhes.documentId] }
    : { tabId: detalhes.tabId };
  try {
    await chrome.scripting.executeScript({ target: alvo, files: ["inject.js"], injectImmediately: true });
  } catch (erro) {
    console.warn("[Site Guard] não foi possível injetar o aviso:", erro?.message);
  }
}

// ---------------------------------------------------------------------------
// Navegação
// ---------------------------------------------------------------------------

async function tratarNavegacao(detalhes) {
  const urlStr = detalhes.url;
  let url;
  try {
    url = new URL(urlStr);
  } catch {
    return;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return;

  const { enabled = true, reported = {} } = await chrome.storage.local.get(["enabled", "reported"]);
  if (!enabled) return;

  const host = semWww(url.hostname.toLowerCase());
  const liberado = await hostLiberado(host);
  let injetado = false;
  const avisar = async () => {
    if (injetado || liberado) return;
    injetado = true;
    await injetarAviso(detalhes);
  };

  // Lista fixa / reportados: dispensam o score
  if (isListed(host, DANGEROUS_HOSTS) || isListed(host, reported)) {
    await avisar();
    const resultado = { score: 100, flags: ["lista"] };
    await enqueue(() => registrarVisita(urlStr, "dangerous", resultado));
    return;
  }

  // Fase 1 — só a URL (rápido, sem rede)
  const local = avaliarLocal(urlStr);
  if (!local) return;
  if (classificar(local.score) === "dangerous") await avisar();

  // Fase 2 — servidor (SSL, DNS, idade do domínio, redirecionamento)
  let final = local;
  if (!local.local && !local.ehIp && !ehSiteOficial(local.host)) {
    const rede = await consultarServidor(local.host);
    if (rede) final = aplicarRede(local, rede);
  }

  const status = classificar(final.score);
  if (status === "dangerous") await avisar();

  await enqueue(() => registrarVisita(urlStr, status, final));
}

// ---------------------------------------------------------------------------
// Eventos
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener(() => {
  enqueue(async () => {
    const stored = await chrome.storage.local.get(["enabled", "totals", "hourly", "reported"]);
    await chrome.storage.local.set({
      enabled: stored.enabled ?? true,
      totals: stored.totals ?? { ...EMPTY_TOTALS },
      hourly: stored.hourly ?? {},
      reported: stored.reported ?? {},
    });
  });
});

chrome.webNavigation.onCommitted.addListener((detalhes) => {
  if (detalhes.frameId !== 0) return; // só a página principal
  tratarNavegacao(detalhes).catch((erro) => console.error("[Site Guard]", erro));
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "REPORT_SITE" && typeof message.host === "string") {
    enqueue(() => reportSite(message.host)).then(
      () => sendResponse({ ok: true }),
      () => sendResponse({ ok: false })
    );
    return true; // resposta assíncrona
  }

  // Enviado pelo inject.js quando o usuário escolhe prosseguir
  if (message?.type === "LIBERAR_SITE" && sender.tab?.url) {
    try {
      const host = semWww(new URL(sender.tab.url).hostname.toLowerCase());
      enqueue(() => liberarHost(host));
    } catch {
      /* URL inválida */
    }
  }
});
