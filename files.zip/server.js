// Servidor de consultas (SSL, DNS, idade do domínio, redirecionamento).
// Requer Node 18+ (fetch nativo). Para ler o .env sem dependências: Node 20.6+
//   node --env-file=.env server.js
//
// Privacidade: o domínio chega cifrado (AES-256-GCM) e NÃO é escrito em logs nem
// devolvido na resposta.

const express = require('express');
const https = require('https');
const http = require('http');
const dns = require('dns');
const net = require('net');
const crypto = require('crypto');

const PORT = Number(process.env.APP_PORT) || 3000;
const CHAVE = Buffer.from(process.env.KEY_DECODE || '', 'base64');
if (CHAVE.length !== 32) {
    console.error('KEY_DECODE ausente ou inválida: use 32 bytes em base64 (veja .env.example).');
    process.exit(1);
}

const JANELA_MS = 60_000; // requisições mais antigas que isso são recusadas (anti-replay)
const TIMEOUT_MS = 3000;

const ENCURTADORES_CONHECIDOS = [
    'bit.ly', 'tinyurl.com', 'goo.gl', 't.co', 'is.gd',
    'buff.ly', 'adf.ly', 'bl.ink', 'lnkd.in', 'rebrand.ly', 'migre.me'
];

const SLDS_COMPOSTOS = new Set(['com', 'net', 'org', 'gov', 'edu', 'co', 'ac', 'mil']);
const DOMINIO_REGEX = /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9-]{2,63}$/;

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '2kb' }));

// ---------------------------------------------------------------------------
// Decodificação
// Formato: base64url( iv[12] | texto cifrado | tag[16] )
// ---------------------------------------------------------------------------
function decodificar(payload) {
    const bruto = Buffer.from(payload, 'base64url');
    if (bruto.length < 12 + 16 + 1) throw new Error('payload inválido');

    const iv = bruto.subarray(0, 12);
    const tag = bruto.subarray(bruto.length - 16);
    const cifrado = bruto.subarray(12, bruto.length - 16);

    const decifrador = crypto.createDecipheriv('aes-256-gcm', CHAVE, iv);
    decifrador.setAuthTag(tag);
    const texto = Buffer.concat([decifrador.update(cifrado), decifrador.final()]).toString('utf8');
    return JSON.parse(texto);
}

// ---------------------------------------------------------------------------
// Proteção contra SSRF: nunca conectar em endereços internos
// ---------------------------------------------------------------------------
function ipPrivado(ip) {
    if (ip.startsWith('::ffff:')) ip = ip.slice(7);
    if (net.isIPv4(ip)) {
        const [a, b] = ip.split('.').map(Number);
        return a === 0 || a === 10 || a === 127 || a >= 224
            || (a === 100 && b >= 64 && b <= 127)
            || (a === 169 && b === 254)
            || (a === 172 && b >= 16 && b <= 31)
            || (a === 192 && b === 168)
            || (a === 198 && (b === 18 || b === 19));
    }
    const v6 = ip.toLowerCase();
    return v6 === '::' || v6 === '::1'
        || v6.startsWith('fc') || v6.startsWith('fd')
        || v6.startsWith('fe8') || v6.startsWith('fe9') || v6.startsWith('fea') || v6.startsWith('feb');
}

// Valida o IP no momento da conexão (evita "DNS rebinding")
function lookupSeguro(hostname, opcoes, callback) {
    dns.lookup(hostname, opcoes, (erro, endereco, familia) => {
        if (erro) return callback(erro);
        const lista = Array.isArray(endereco) ? endereco : [{ address: endereco, family: familia }];
        if (lista.some((item) => ipPrivado(item.address))) {
            return callback(new Error('endereço bloqueado'));
        }
        callback(null, endereco, familia);
    });
}

function dominioValido(dominio) {
    return DOMINIO_REGEX.test(dominio) && !net.isIP(dominio) && dominio !== 'localhost';
}

function dominioRegistravel(host) {
    const p = host.split('.');
    if (p.length <= 2) return host;
    const tld = p[p.length - 1];
    const sld = p[p.length - 2];
    return tld.length === 2 && SLDS_COMPOSTOS.has(sld) ? p.slice(-3).join('.') : p.slice(-2).join('.');
}

// ---------------------------------------------------------------------------
// Consultas
// ---------------------------------------------------------------------------

// HEAD sem seguir redirecionamentos. Retorna o status HTTP, ou null se não conectou
// (para HTTPS, null = sem SSL válido ou indisponível).
function head(dominio, seguro) {
    return new Promise((resolve) => {
        const modulo = seguro ? https : http;
        const req = modulo.request({
            hostname: dominio,
            port: seguro ? 443 : 80,
            method: 'HEAD',
            path: '/',
            timeout: TIMEOUT_MS,
            lookup: lookupSeguro,
            agent: false
        }, (res) => {
            res.resume();
            resolve(res.statusCode);
        });

        req.on('error', () => resolve(null));
        req.on('timeout', () => {
            req.destroy();
            resolve(null);
        });
        req.end();
    });
}

async function resolverDns(dominio) {
    try {
        await dns.promises.lookup(dominio, { all: true });
        return true;
    } catch {
        return false;
    }
}

// Data de registro via RDAP (rdap.org direciona para o registro do TLD)
async function idadeDoDominioEmDias(dominio) {
    try {
        const resposta = await fetch(`https://rdap.org/domain/${dominioRegistravel(dominio)}`, {
            headers: { accept: 'application/rdap+json' },
            signal: AbortSignal.timeout(4000)
        });
        if (!resposta.ok) return null;
        const dados = await resposta.json();
        const evento = (dados.events || []).find((e) => e.eventAction === 'registration');
        if (!evento) return null;
        return Math.floor((Date.now() - new Date(evento.eventDate).getTime()) / 86_400_000);
    } catch {
        return null;
    }
}

// ---------------------------------------------------------------------------
// Rota
// ---------------------------------------------------------------------------
app.post('/analisar', async (req, res) => {
    let dados;
    try {
        dados = decodificar(String(req.body?.d ?? ''));
    } catch {
        return res.status(400).json({ erro: 'payload inválido' });
    }

    if (typeof dados.h !== 'string' || Math.abs(Date.now() - Number(dados.t)) > JANELA_MS) {
        return res.status(400).json({ erro: 'requisição expirada ou malformada' });
    }

    const dominio = dados.h.toLowerCase().replace(/^www\./, '');
    if (!dominioValido(dominio)) {
        return res.status(400).json({ erro: 'domínio inválido' });
    }

    try {
        const [statusHttps, dnsOk, idade] = await Promise.all([
            head(dominio, true),
            resolverDns(dominio),
            idadeDoDominioEmDias(dominio)
        ]);

        const possuiSsl = statusHttps !== null;
        const statusFinal = possuiSsl ? statusHttps : await head(dominio, false);

        return res.json({
            ssl: possuiSsl,
            dns: dnsOk,
            idade_dias: idade,
            redirecionamento: statusFinal !== null && statusFinal >= 300 && statusFinal < 400,
            encurtador: ENCURTADORES_CONHECIDOS.includes(dominio)
        });
    } catch {
        return res.status(500).json({ erro: 'falha na análise' });
    }
});

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
